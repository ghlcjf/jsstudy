function login() {
  location.href = "loginpage.html";
}
function signup(){
  location.href = "signup.html";
}
function bulletinboard() {
  location.href = "bulletinboard.html";
}
function imageP(){
  location.href = "imagepage.html";
}