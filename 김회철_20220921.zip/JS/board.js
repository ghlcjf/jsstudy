function main(){
  location.href = "./mainpage.html";
}
function writeP(){
  location.href = "./write.html";
}
function postP(){
  location.href = "./post.html";
}