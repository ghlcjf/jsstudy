function main(){
  alert('메인화면으로 이동합니다.')
  location.href = "./mainpage.html";
}
function gugu(){
  location.href = "./gugudan.html";
}