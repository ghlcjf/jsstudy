function correct(){
  // let c = confirm('게시글을 수정하시겠습니까?');
  // if(c){
  //   location.href = "./write.html";
  // }
  alert('수정 페이지로 이동합니다.');
  location.href = "./write.html";
}
function del(){
  // let d = confirm('게시글을 삭제하시겠습니까?');
  // if(d){
  //   location.href = "./bulletinboard.html";
  // }
  alert('게시글을 삭제합니다.');
  location.href = "./bulletinboard.html";
}
function board(){
  // let b = confirm('게시글 목록으로 이동하시겠습니까?');
  // if(b) {
  //   location.href = "./bulletinboard.html";
  // }
  alert('게시판으로 이동합니다.');
  location.href = "./bulletinboard.html";
}